// Arcade Store with Image Upload

let products=[
  {id:1,title:"PUBG UC",description:"شدات ببجي موبايل",priceUSD:5.99,stock:20,image:"https://via.placeholder.com/220x150?text=PUBG"},
  {id:2,title:"Free Fire Diamonds",description:"جواهر فري فاير",priceUSD:3.50,stock:15,image:"https://via.placeholder.com/220x150?text=FF"},
  {id:3,title:"Clash of Clans Gems",description:"جواهر كلاش",priceUSD:4.99,stock:12,image:"https://via.placeholder.com/220x150?text=COC"},
];
if(localStorage.getItem("products")) products=JSON.parse(localStorage.getItem("products"));
let cart=JSON.parse(localStorage.getItem("cart")||"[]");
let orders=JSON.parse(localStorage.getItem("orders")||"[]");
let reviews=JSON.parse(localStorage.getItem("reviews")||"{}");

const rates={USD:1,EGP:50,EUR:0.9};
let currentCurrency="USD";

function saveData(){localStorage.setItem("products",JSON.stringify(products));localStorage.setItem("cart",JSON.stringify(cart));localStorage.setItem("orders",JSON.stringify(orders));localStorage.setItem("reviews",JSON.stringify(reviews));}
function convertPrice(usd){return (usd*rates[currentCurrency]).toFixed(2);}
function currencySymbol(){return currentCurrency==="USD"?"$":currentCurrency==="EGP"?"ج.م":"€";}

const grid=document.getElementById("productsGrid");
function renderProducts(){grid.innerHTML="";products.forEach(p=>{let card=document.createElement("div");card.className="card";card.innerHTML=`
<img src="${p.image}" alt="${p.title}" style="width:100%;border-radius:10px;">
<h3>${p.title}</h3>
<p>${p.description}</p>
<div>السعر: ${convertPrice(p.priceUSD)} ${currencySymbol()}</div>
<div>المتوفر: ${p.stock}</div>
<button class="btn primary" ${p.stock<=0?"disabled":""}>أضف للسلة</button>`;card.querySelector("button").onclick=()=>addToCart(p.id);card.ondblclick=()=>showProduct(p.id);grid.appendChild(card);});}

function addToCart(id){let p=products.find(x=>x.id===id);if(!p||p.stock<=0) return alert("غير متاح");let item=cart.find(i=>i.id===id);if(item){if(item.qty<p.stock)item.qty++;else return alert("لا يوجد ستوك كافي");}else cart.push({id:id,qty:1});updateCart();}
function updateCart(){document.getElementById("cartCount").textContent=cart.reduce((a,b)=>a+b.qty,0);saveData();}
function renderCart(){const cartItems=document.getElementById("cartItems");cartItems.innerHTML="";let total=0;cart.forEach(item=>{let p=products.find(pr=>pr.id===item.id);if(!p) return;total+=p.priceUSD*item.qty;let div=document.createElement("div");div.className="cart-item";div.innerHTML=`${p.title} x ${item.qty} = ${convertPrice(p.priceUSD*item.qty)} ${currencySymbol()} <button data-id="${item.id}">حذف</button>`;div.querySelector("button").onclick=()=>{cart=cart.filter(c=>c.id!==item.id);updateCart();renderCart();};cartItems.appendChild(div);});document.getElementById("cartTotal").textContent=convertPrice(total)+" "+currencySymbol();saveData();}

function showProduct(id){const p=products.find(x=>x.id===id);if(!p) return;document.getElementById("productDetails").innerHTML=`
<h2>${p.title}</h2>
<img src="${p.image}" style="width:100%;border-radius:12px;">
<p>${p.description}</p>
<div>السعر: ${convertPrice(p.priceUSD)} ${currencySymbol()}</div>
<div>المتوفر: ${p.stock}</div>
<button class="btn primary" ${p.stock<=0?"disabled":""}>أضف للسلة</button>`;document.getElementById("productDetails").querySelector("button").onclick=()=>addToCart(p.id);renderReviews(id);document.getElementById("addReviewBtn").onclick=()=>{const text=document.getElementById("reviewText").value.trim();const stars=parseInt(document.getElementById("reviewStars").value)||5;if(!text) return alert("اكتب تعليق");if(!reviews[id])reviews[id]=[];reviews[id].push({text,stars});document.getElementById("reviewText").value="";saveData();renderReviews(id);};document.getElementById("productModal").setAttribute("aria-hidden","false");}
function renderReviews(id){const list=document.getElementById("reviewsList");list.innerHTML="";(reviews[id]||[]).forEach((r,i)=>{let div=document.createElement("div");div.className="review";div.innerHTML=`⭐${r.stars} - ${r.text} <button data-del="${i}">❌</button>`;div.querySelector("button").onclick=()=>{reviews[id].splice(i,1);saveData();renderReviews(id);};list.appendChild(div);});}

const cartBtn=document.getElementById("cartBtn"),cartModal=document.getElementById("cartModal"),closeCartModal=document.getElementById("closeCartModal");cartBtn.onclick=()=>{renderCart();cartModal.setAttribute("aria-hidden","false");};closeCartModal.onclick=()=>cartModal.setAttribute("aria-hidden","true");document.getElementById("clearCartBtn").onclick=()=>{cart=[];updateCart();renderCart();};document.getElementById("checkoutBtn").onclick=()=>{if(cart.length==0)return alert("السلة فارغة");orders.push({id:Date.now(),items:[...cart]});cart=[];updateCart();renderCart();alert("تم الطلب");};

const productModal=document.getElementById("productModal"),closeProductModal=document.getElementById("closeProductModal");closeProductModal.onclick=()=>productModal.setAttribute("aria-hidden","true");

const loginModal=document.getElementById("loginModal"),closeLoginModal=document.getElementById("closeLoginModal"),loginBtn=document.getElementById("loginBtn"),loginMsg=document.getElementById("loginMsg");
document.getElementById("adminBtn").onclick=()=>{loginModal.setAttribute("aria-hidden","false");}
closeLoginModal.onclick=()=>loginModal.setAttribute("aria-hidden","true");
loginBtn.onclick=()=>{const u=document.getElementById("loginUser").value.trim();const p=document.getElementById("loginPass").value.trim();if(u==="adham"&&p==="adham@2005"){loginModal.setAttribute("aria-hidden","true");renderAdmin();adminModal.setAttribute("aria-hidden","false");}else{loginMsg.textContent="بيانات غير صحيحة";}}

const adminModal=document.getElementById("adminModal"),closeAdminModal=document.getElementById("closeAdminModal");closeAdminModal.onclick=()=>adminModal.setAttribute("aria-hidden","true");

function renderAdmin(){const adminArea=document.getElementById("adminArea");adminArea.innerHTML=`<h2>لوحة التحكم</h2><button id="addProductBtn" class="btn">إضافة منتج</button>`;products.forEach(p=>{let div=document.createElement("div");div.innerHTML=`${p.title} ($${p.priceUSD}) ستوك:${p.stock} <button data-edit="${p.id}">تعديل</button> <button data-del="${p.id}">حذف</button>`;adminArea.appendChild(div);});adminArea.querySelectorAll("[data-del]").forEach(b=>b.onclick=()=>{products=products.filter(pr=>pr.id!=b.dataset.del);saveData();renderAdmin();});adminArea.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>{editProduct(parseInt(b.dataset.edit));});document.getElementById("addProductBtn").onclick=()=>editProduct(null);}

function editProduct(id){let prod=id?products.find(p=>p.id==id):{title:"",description:"",priceUSD:0,stock:0,image:""};const adminArea=document.getElementById("adminArea");adminArea.innerHTML=`<h3>${id?"تعديل":"إضافة"} منتج</h3>
<input id="pTitle" placeholder="العنوان" value="${prod.title}"><br>
<input id="pDesc" placeholder="الوصف" value="${prod.description}"><br>
<input id="pPrice" type="number" placeholder="السعر USD" value="${prod.priceUSD}"><br>
<input id="pStock" type="number" placeholder="الستوك" value="${prod.stock}"><br>
<input id="pImage" type="file" accept="image/*"><br>
<button id="saveProductBtn" class="btn primary">حفظ</button>`;
document.getElementById("saveProductBtn").onclick=()=>{const title=document.getElementById("pTitle").value;const desc=document.getElementById("pDesc").value;const price=parseFloat(document.getElementById("pPrice").value)||0;const stock=parseInt(document.getElementById("pStock").value)||0;const file=document.getElementById("pImage").files[0];if(file){const reader=new FileReader();reader.onload=function(e){prod.image=e.target.result;saveProd();};reader.readAsDataURL(file);}else{saveProd();}function saveProd(){prod.title=title;prod.description=desc;prod.priceUSD=price;prod.stock=stock;if(!id){prod.id=Date.now();products.push(prod);}saveData();renderAdmin();renderProducts();}};}

document.getElementById("currencySelect").onchange=e=>{currentCurrency=e.target.value;renderProducts();renderCart();}

renderProducts();updateCart();
